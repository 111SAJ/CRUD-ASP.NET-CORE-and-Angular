import { Component } from '@angular/core';

@Component({
  selector: 'app-secured-page',
  templateUrl: './secured-page.component.html',
  styleUrl: './secured-page.component.css'
})
export class SecuredPageComponent {

}
